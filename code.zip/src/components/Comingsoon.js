import React from "react";

const ComingSoon=()=>{
    return (
        <>
        <h1>comming soon</h1>
        </>
    )
}
export default ComingSoon