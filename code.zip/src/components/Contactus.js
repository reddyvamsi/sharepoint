
import  "./Contactus.css"
import conUS from '../images/conUS.jpg';
import React, {useState } from "react";
//import {useNavigate}from 'react-router-dom';
import { useParams } from "react-router-dom";
import './Applayforjob.css'
import {  useSelector } from "react-redux";
//import {contactus} from '../redux/JobActions'
import axios from "axios";

const Contactus=()=>{
  const params = useParams();
  const [simpleTextDisplay, setSimpleTextDisplay] = useState(false);
  const [values, setValues] = useState({
    Name: "",
    Email: "",
    Password: "",
   Message: "",
  });
  const handleEditcontactus = (e) => {
     e.preventDefault()
  axios.post('http://localhost:1111/contactus',values).then(res => {
         console.log(values);
      })
    };
    return(
        <>
        <div class="container">
            <div class="row" style={{position:"relative",top: "3rem"}}>
                <div class="col-6">
                <p className="titlestyle">Get In Touch</p>
              <form>
    <div class="form-group">
    <input type="text"  class="form-control inputsapce"
    value={values.Name}  
    onChange={(e) => setValues({ ...values, Name: e.target.value })}
     id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Name"></input>
  </div>
  <div class="form-group">
    <input type="email" class="form-control inputsapce"
     value={values.Email} 
     onChange={(e) => setValues({ ...values, Email: e.target.value })}
     id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email"></input>
  </div>
  <div class="form-group">
    <input type="password" class="form-control inputsapce"
value={values.Password} 
onChange={(e) => setValues({ ...values, Password: e.target.value })}
     id="exampleInputPassword1" placeholder="Password"></input>
  </div>
  <div class="form-group">
    <textarea class="form-control inputsapce"
    value={values.Message} 
    onChange={(e) => setValues({ ...values, Message: e.target.value })}
     id="exampleFormControlTextarea1" placeholder="Message" rows="3"></textarea>
  </div>
  <button type="submit" 
    onClick={handleEditcontactus}
  class="btn btn-primary col-12">Submit</button>
</form>
                </div>
                <div class="col-6 ">
                <img style={{height:"400px"}}
                        className="d-block w-100"
                        src={conUS}
                        alt="First slide"
                    />
                </div>
            </div>
        </div>
        </>
    ) 
   
}
export default Contactus