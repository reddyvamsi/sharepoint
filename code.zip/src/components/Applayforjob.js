import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import './Applayforjob.css'
//import {useForm} from 'react-hook-form'
import { useDispatch, useSelector } from "react-redux";
import {getEmp} from '../redux/JobActions'
import axios from "axios";

const Applayforjob=()=>{
    const params = useParams();
  const [simpleTextDisplay, setSimpleTextDisplay] = useState(false);
  const [values, setValues] = useState({
    JobId: params.id,
    Name: "",
    Email: "",
    Mobile: "",
    Experience: "",
  });
  //const { users } = useSelector((state) => state.users);
  const jobs =useSelector(state => state.users.jobs)
  let dispatch = useDispatch();

  useEffect(() => {
    dispatch(getEmp());
  }, [dispatch]);

  const handleEditUser = (e) => {
    e.preventDefault();
  setValues({Name: "", Email: "", Mobile: "", Experience: "" });
  console.log(setValues);
  setSimpleTextDisplay(true);
  axios.post('http://localhost:1111/Appliedjobs',values).then(res => {
         console.log(values);
      })
    };
return (
    <>
    <div class="container">
            <div class="row" style={{position:"relative",top: "3rem"}}>
                <div class="col-12">
                <p className="titlestyle">Applay For Job</p>
              <form>
    <div class="form-group">
    <input type="text"  value={values.Name}  
     onChange={(e) => setValues({ ...values, Name: e.target.value })}
    class="form-control inputsapce" id="exampleInputEmail1" 
    aria-describedby="emailHelp" placeholder="Name"></input>
  </div>
  <div class="form-group">
    <input type="email"  value={values.Email} 
     onChange={(e) => setValues({ ...values, Email: e.target.value })}
    class="form-control inputsapce" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email"></input>
  </div>
  <div class="form-group">
    <input type="number"  value={values.Mobile}
     onChange={(e) => setValues({ ...values, Mobile: e.target.value })} 
    class="form-control inputsapce" id="exampleInputPassword1" placeholder="Enter mobile number"></input>
    </div>
   
    <div class="form-group">
    <input type="text"  value={values.Experience}
     onChange={(e) => setValues({ ...values, Experience: e.target.value })}
     class="form-control inputsapce" id="exampleInputPassword1" placeholder="Experiance"></input>
    </div>
    <button type="submit"
     onClick={handleEditUser}
     class="btn btn-primary col-lg-12 col-12">Submit</button>
      {simpleTextDisplay ? (
          <div>
            <h1 className="text-danger">Application Details</h1>
            <h3>Job Id: {params.id}</h3>
            <p>{jobs[params.id].company}</p>
            <p>{jobs[params.id].salary}</p>
            <p>{jobs[params.id].location}</p>
            <p>{jobs[params.id].role}</p>
          </div>
        ) : (
          ""
        )}
    </form>
     </div>
    </div>
    </div>
    
    </>
    );
}
export default Applayforjob