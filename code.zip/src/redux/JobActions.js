import axios from "axios";
export const getEmp = () => {
    return async function(dispatch, getState) {
        await axios.get('http://localhost:1111/jobs')
        .then(data => {
            console.log("krishna", data);
            return dispatch({
                type: "employee/getById",
                data: data.data
            });
        });
    };
}

export const applyjobs = (info) => {
    console.log(info);
    return function(dispatch){
        console.log(info);
        axios.post('http://localhost:1111/jobs',info).then(res => {
           console.log()
        })
        .catch(error => console.log(error));
    }
}
//testing

// export const empcantact = (contactus) => {
//     if (contactus) {
//         return async function(dispatch, getState) {
//             await axios.post('http://localhost:1111/contactus', contactus)
//             .then(data => {
//                 console.log("vamsikrishna", data);
//             });
//         };
//     }
// }











export const contactus=(contact)=>{
    console.log();
    return function(dispatch){
    axios.post('http://localhost:1111/contactus',contact).then(res =>{
        console.log(res);
    })
    .catch(error => console.log(error));
    }
}